JARVIS – einfache iPhone-Web-App

Die Oberfläche ist komplett auf JARVIS umbenannt und für den Home-Bildschirm vorbereitet.

Einmalig:
1. Diese Dateien auf eine HTTPS-Webadresse hochladen.
2. Die Adresse in Safari öffnen.
3. Teilen → Zum Home-Bildschirm → Hinzufügen.

Danach erscheint JARVIS wie eine App.

Hinweis: Die ChatGPT/OpenAI-Funktion benötigt weiterhin einen sicheren Server unter /api/chat. Der API-Schlüssel gehört niemals in index.html.
